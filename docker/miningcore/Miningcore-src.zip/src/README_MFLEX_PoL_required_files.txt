    Miningcore MFLEX PoL required files
    Generated: 2026-01-09 06:56:05Z

    This ZIP contains only the Miningcore source files that were changed for MFLEX PoL support:

    - Miningcore/Stratum/StratumConnection.cs
- Miningcore/Blockchain/Bitcoin/BitcoinPool.cs
- Miningcore/Blockchain/Bitcoin/BitcoinJob.cs
- Miningcore/Blockchain/Bitcoin/BitcoinJobManager.cs
- Miningcore/Blockchain/Bitcoin/BitcoinJobManagerBase.cs
- Miningcore/Blockchain/Bitcoin/BitcoinPayoutHandler.cs

    Copy these files into your Miningcore repository (overwrite), then rebuild.
