namespace Miningcore.Blockchain.Bitcoin.DaemonResponses;

public class MwebBlockTemplateExtra
{
    public string Mweb { get; set; }
}
