using System;
using System.Buffers;
using System.IO;
using System.Net;
using System.Net.WebSockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace Miningcore.Api
{
    [ApiController]
    [Route("api/tools/latency")]
    public class LatencyApiController : ControllerBase
    {
        /// <summary>
        /// WebSocket echo endpoint.
        /// Client connects to: ws(s)://<host>/api/tools/latency/ws
        /// We immediately echo back each message to measure RTT.
        /// </summary>
        [HttpGet("ws")]
        public async Task<IActionResult> WebSocketEcho()
        {
            if (!HttpContext.WebSockets.IsWebSocketRequest)
                return BadRequest("WebSocket expected.");

            using var webSocket = await HttpContext.WebSockets.AcceptWebSocketAsync();
            var buffer = ArrayPool<byte>.Shared.Rent(8 * 1024);
            try
            {
                while (true)
                {
                    var result = await webSocket.ReceiveAsync(new ArraySegment<byte>(buffer), CancellationToken.None);
                    if (result.MessageType == WebSocketMessageType.Close)
                    {
                        await webSocket.CloseAsync(WebSocketCloseStatus.NormalClosure, "bye", CancellationToken.None);
                        break;
                    }

                    // Echo the exact payload back
                    var outgoing = new ArraySegment<byte>(buffer, 0, result.Count);
                    await webSocket.SendAsync(outgoing, result.MessageType, result.EndOfMessage, CancellationToken.None);
                }
            }
            catch (WebSocketException)
            {
                // client disconnected or network error; just end
            }
            finally
            {
                ArrayPool<byte>.Shared.Return(buffer);
            }

            return new EmptyResult();
        }

        /// <summary>
        /// Download endpoint for throughput measurement.
        /// GET /api/tools/latency/down?bytes=2000000  -> returns N raw bytes
        /// </summary>
        [HttpGet("down")]
        public IActionResult Down([FromQuery] long bytes = 2_000_000)
        {
            if (bytes <= 0)
                bytes = 1;

            // Cap to something sane (e.g., 32 MB) to avoid abuse
            const long max = 32L * 1024 * 1024;
            if (bytes > max)
                bytes = max;

            // Stream zeros; content doesn't matter
            var stream = new LatencyZeroStream(bytes);
            return File(stream, "application/octet-stream", enableRangeProcessing: false);
        }

        /// <summary>
        /// Upload endpoint for throughput measurement.
        /// POST /api/tools/latency/up  (send raw body; we just read it)
        /// Returns: { receivedBytes: N }
        /// </summary>
        [HttpPost("up")]
        public async Task<IActionResult> Up()
        {
            long total = 0;
            var buffer = ArrayPool<byte>.Shared.Rent(64 * 1024);
            try
            {
                int read;
                while ((read = await Request.Body.ReadAsync(buffer, 0, buffer.Length)) > 0)
                    total += read;
            }
            finally
            {
                ArrayPool<byte>.Shared.Return(buffer);
            }

            return new JsonResult(new { receivedBytes = total });
        }

        /// <summary>
        /// Simple stream that returns a specified number of zero bytes.
        /// </summary>
        private class LatencyZeroStream : Stream
        {
            private long remaining;

            public LatencyZeroStream(long bytes)
            {
                remaining = bytes;
            }

            public override bool CanRead => true;
            public override bool CanSeek => false;
            public override bool CanWrite => false;
            public override long Length => throw new NotSupportedException();
            public override long Position { get => throw new NotSupportedException(); set => throw new NotSupportedException(); }
            public override void Flush() { }
            public override long Seek(long offset, SeekOrigin origin) => throw new NotSupportedException();
            public override void SetLength(long value) => throw new NotSupportedException();
            public override void Write(byte[] buffer, int offset, int count) => throw new NotSupportedException();

            public override int Read(byte[] buffer, int offset, int count)
            {
                if (remaining <= 0)
                    return 0;

                int toWrite = (int)Math.Min(count, remaining);
                Array.Clear(buffer, offset, toWrite);
                remaining -= toWrite;
                return toWrite;
            }

#if NET6_0_OR_GREATER
            public override int Read(Span<byte> destination)
            {
                if (remaining <= 0)
                    return 0;

                int toWrite = (int)Math.Min(destination.Length, remaining);
                destination[..toWrite].Clear();
                remaining -= toWrite;
                return toWrite;
            }
#endif
        }
    }
}
