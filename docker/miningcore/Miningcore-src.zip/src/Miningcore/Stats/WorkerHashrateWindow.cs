using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;

namespace Miningcore.Stats
{
    public class WorkerHashrateSample
    {
        public DateTime Timestamp { get; init; }
        public double Difficulty { get; init; }
    }

    /// <summary>
    /// Kurzes Hashrate-Fenster (Standard: 60 Sekunden) pro Pool/Miner/Worker.
    /// </summary>
    public class WorkerHashrateWindow
    {
        // Key: poolId:miner:worker
        private readonly ConcurrentDictionary<string, List<WorkerHashrateSample>> _samples
            = new ConcurrentDictionary<string, List<WorkerHashrateSample>>();

        private readonly TimeSpan window = TimeSpan.FromSeconds(60);

        private static string BuildKey(string poolId, string miner, string worker)
            => $"{poolId}:{miner}:{worker}";

        public void AddShare(string poolId, string miner, string worker, double difficulty)
        {
            if(string.IsNullOrEmpty(miner) || string.IsNullOrEmpty(worker))
                return;

            var key = BuildKey(poolId, miner, worker);
            var now = DateTime.UtcNow;

            var list = _samples.GetOrAdd(key, _ => new List<WorkerHashrateSample>());

            lock(list)
            {
                list.Add(new WorkerHashrateSample
                {
                    Timestamp = now,
                    Difficulty = difficulty
                });

                var cutoff = now - window;
                list.RemoveAll(x => x.Timestamp < cutoff);
            }
        }

        public double GetShortTermHashrate(string poolId, string miner, string worker)
        {
            var key = BuildKey(poolId, miner, worker);
            if(!_samples.TryGetValue(key, out var list))
                return 0;

            var now = DateTime.UtcNow;
            var cutoff = now - window;

            lock(list)
            {
                var recent = list.Where(x => x.Timestamp >= cutoff).ToList();
                if(recent.Count == 0)
                    return 0;

                var totalDiff = recent.Sum(x => x.Difficulty);
                var seconds = window.TotalSeconds;

                // H/s ≈ diff * 2^32 / sec
                var hash = totalDiff * Math.Pow(2, 32) / seconds;
                return hash;
            }
        }

        public int WindowSeconds => (int) window.TotalSeconds;
    }
}
