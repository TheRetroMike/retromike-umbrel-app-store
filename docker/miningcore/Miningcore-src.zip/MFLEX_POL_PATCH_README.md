# MFLEX / PoL Patch fuer Miningcore (Austausch-ZIP)

Dieses ZIP enthaelt nur die geaenderten/neu hinzugefuegten Dateien, um MFLEX / PoL (Proof of Lottery/PoL) im Miningcore-Stratum fuer Bitcoin-Family (SHA256) zu aktivieren.

**Wichtig:** PoL ist pro Pool **opt-in**. Wenn der Schalter nicht gesetzt ist, verhaelt sich Miningcore fuer diesen Pool wie das Original ("vanilla").

## Ziel-Pfade

Wir gehen davon aus, dass dein Miningcore Source-Tree hier liegt:

- Quellen: `/miningcore/src`
- Build Output: `/miningcore/build`

Die Dateien in diesem ZIP sind so strukturiert, dass du es **direkt nach `/miningcore/src`** entpacken kannst.

## Installation (Overwrite-Patch)

1. Miningcore stoppen.
2. Optional: Backup der Originaldateien erstellen (empfohlen).
3. Patch entpacken und vorhandene Dateien ueberschreiben:

```bash
cd /miningcore/src
unzip -o Miningcore-MFLEX-PoL-Patch-fixed.zip
```

> Hinweis: Wenn dein ZIP anders heisst (oder du es umbenennst), ersetze den Namen entsprechend.

## Build / "neu backen"

Beispiel (Linux):

```bash
mkdir -p /miningcore/build
cd /miningcore/src/Miningcore

dotnet restore
# Build/Publish in /miningcore/build
dotnet publish -c Release --framework net6.0 -o /miningcore/build
```

Optional (wenn du explizit ein Runtime-Target willst):

```bash
# Beispiel linux-x64
 dotnet publish -c Release --framework net6.0 -r linux-x64 --self-contained false -o /miningcore/build
```

Start:

```bash
cd /miningcore/build
./Miningcore -c /miningcore/config.json
```

## config.json: MFLEX/PoL aktivieren (pro Pool)

Der Schalter wird **pro Pool** unter `pools[].extra` gelesen.

### Minimal-Beispiel

```json
{
  "pools": [
    {
      "id": "my-sha256-pool",
      "coin": "BTC",
      "address": "<POOL_PAYOUT_ADDRESS>",
      "extra": {
        "mflex": {
          "enabled": true
        }
      },
      "ports": {
        "3333": {
          "listenAddress": "0.0.0.0",
          "difficulty": 1000
        }
      },
      "daemons": [
        {
          "host": "127.0.0.1",
          "port": 8332,
          "user": "rpcuser",
          "password": "rpcpass"
        }
      ]
    }
  ]
}
```

### Was passiert, wenn enabled=false oder fehlt?

- Miningcore liefert fuer diesen Pool wieder den "normalen" Job (kein per-miner Coinbase-Delta, kein MFLEXID-OP_RETURN).
- Damit bleiben andere SHA256 Coins/Pools unbeeinflusst.

### Weitere akzeptierte Schreibweisen

Der Code akzeptiert auch:

- `"mflexEnabled": true`
- `"pol": { "enabled": true }`
- `"polEnabled": true`

Empfohlen ist aber:

```json
"extra": { "mflex": { "enabled": true } }
```

## Anforderungen / Hinweise

- Der zugehoerige Coin-Daemon muss die PoL-RPC `getpolallowedtag` unterstuetzen (und PoL auf Block-Validierungsebene enforce'n), sonst kann PoL nicht korrekt betrieben werden.
- Dieser Patch enthaelt **keine** Payout-basierte Jackpot/Lottery Logik (bewusst entfernt), da Jackpot/Lottery spaeter nicht ueber Payout laufen soll.

## Enthaltene Dateien (Uebersicht)

- `Miningcore/AutofacModule.cs` (DI Registrierung fuer WorkerConnectionTracker)
- `Miningcore/Stratum/*` (WorkerConnectionTracker + Connection/Server Anpassungen)
- `Miningcore/Blockchain/Bitcoin/*` (PoL Job-/Coinbase Anpassungen)

